import { Injectable, computed, signal } from '@angular/core';
import { AppRole, UserSession } from '../../models/user-session.model';

const SESSION_KEY = 'horizon-session';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly defaultSession: UserSession = {
    id: 'u-1001',
    name: 'Mohammad Ali',
    email: 'tourist@horizon.app',
    role: 'tourist',
    verified: true,
  };

  private readonly sessionState = signal<UserSession>(this.readStoredSession());
  readonly currentUser = computed(() => this.sessionState());
  readonly currentRole = computed(() => this.sessionState().role);

  switchRole(role: AppRole): void {
    const next: UserSession = {
      ...this.sessionState(),
      role,
    };
    this.sessionState.set(next);
    localStorage.setItem(SESSION_KEY, JSON.stringify(next));
  }

  setSession(session: UserSession): void {
    this.sessionState.set(session);
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  }

  clearSession(): void {
    localStorage.removeItem(SESSION_KEY);
    this.sessionState.set(this.defaultSession);
  }

  private readStoredSession(): UserSession {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) {
      return this.defaultSession;
    }

    try {
      return JSON.parse(raw) as UserSession;
    } catch {
      return this.defaultSession;
    }
  }
}
