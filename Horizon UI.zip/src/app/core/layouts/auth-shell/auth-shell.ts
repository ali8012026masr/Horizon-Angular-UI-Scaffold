import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { UserSession } from '../../../models/user-session.model';

interface DemoAccount extends UserSession {
  password: string;
  entryRoute: string;
  label: string;
}

@Component({
  selector: 'app-auth-shell',
  imports: [ReactiveFormsModule],
  templateUrl: './auth-shell.html',
  styleUrl: './auth-shell.scss',
})
export class AuthShell {
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);

  readonly invalid = signal(false);
  readonly showRegister = signal(false);
  readonly registerSuccess = signal(false);
  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  readonly registerForm = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  readonly demoAccounts: DemoAccount[] = [
    {
      id: 'u-1001',
      name: 'Mohammad Ali',
      email: 'tourist@horizon.app',
      role: 'tourist',
      verified: true,
      password: 'tourist123',
      entryRoute: '/tourist/dashboard',
      label: 'Tourist',
    },
    {
      id: 'u-2001',
      name: 'Asif Rahman',
      email: 'provider@horizon.app',
      role: 'provider',
      verified: true,
      password: 'provider123',
      entryRoute: '/provider/dashboard',
      label: 'Service Provider',
    },
    {
      id: 'u-3001',
      name: 'Zamal Uddin',
      email: 'guide@horizon.app',
      role: 'guide',
      verified: true,
      password: 'guide123',
      entryRoute: '/guide/dashboard',
      label: 'Tour Guide',
    },
    {
      id: 'u-4001',
      name: 'System Admin',
      email: 'admin@horizon.app',
      role: 'admin',
      verified: true,
      password: 'admin123',
      entryRoute: '/admin/dashboard',
      label: 'System Admin',
    },
  ];

  login(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const { email, password } = this.form.getRawValue();
    const account = this.demoAccounts.find(
      (demo) => demo.email.toLowerCase() === email.toLowerCase() && demo.password === password
    );

    if (!account) {
      this.invalid.set(true);
      return;
    }

    this.invalid.set(false);
    this.loginAs(account);
  }

  toggleRegister(show: boolean): void {
    this.showRegister.set(show);
    this.registerSuccess.set(false);
  }

  register(): void {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    const { email, password } = this.registerForm.getRawValue();
    this.registerSuccess.set(true);
    this.registerForm.reset();
    this.form.patchValue({ email, password });
    this.showRegister.set(false);
  }

  loginAsDemo(account: DemoAccount): void {
    this.form.patchValue({ email: account.email, password: account.password });
    this.invalid.set(false);
    this.loginAs(account);
  }

  private loginAs(account: DemoAccount): void {
    const { password, entryRoute, label, ...session } = account;
    this.authService.setSession(session as UserSession);
    void this.router.navigateByUrl(entryRoute);
  }
}
