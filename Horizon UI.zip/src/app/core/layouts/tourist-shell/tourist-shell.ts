import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-tourist-shell',
  imports: [RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './tourist-shell.html',
  styleUrl: './tourist-shell.scss',
})
export class TouristShell {
  private readonly authService = inject(AuthService);
  readonly user = this.authService.currentUser;
}
