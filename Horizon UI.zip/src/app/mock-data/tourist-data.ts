import { Injectable } from '@angular/core';
import { delay, Observable, of, throwError } from 'rxjs';
import { Booking } from '../models/booking.model';
import { GuideProfile } from '../models/guide.model';
import { Slot } from '../models/slot.model';
import { TrackingPoint } from '../models/tracking.model';

@Injectable({ providedIn: 'root' })
export class TouristDataService {
  private readonly slots: Slot[] = [
    {
      id: 'slot-1',
      category: 'Bus',
      providerName: 'Dhaka Express',
      origin: 'Dhaka',
      destination: "Cox's Bazar",
      startAt: new Date(Date.now() + 86_400_000).toISOString(),
      capacity: 40,
      availableSeats: 12,
      price: 1800,
    },
    {
      id: 'slot-2',
      category: 'Ship',
      providerName: 'MV Sea Breeze',
      origin: 'Teknaf',
      destination: "Saint Martin's Island",
      startAt: new Date(Date.now() + 172_800_000).toISOString(),
      capacity: 300,
      availableSeats: 80,
      price: 2500,
    },
    {
      id: 'slot-3',
      category: 'Hotel',
      providerName: 'Sea Pearl Stay',
      location: "Cox's Bazar",
      startAt: new Date(Date.now() + 172_800_000).toISOString(),
      endAt: new Date(Date.now() + 345_600_000).toISOString(),
      capacity: 20,
      availableSeats: 6,
      price: 5500,
    },
    {
      id: 'slot-4',
      category: 'Amusement Park',
      providerName: 'Cloud Mist Adventure Park',
      location: 'Sajek Valley',
      startAt: new Date(Date.now() + 259_200_000).toISOString(),
      capacity: 150,
      availableSeats: 50,
      price: 3000,
    },
    {
      id: 'slot-5',
      category: 'Train',
      providerName: 'Jalalabad Express',
      origin: 'Dhaka',
      destination: 'Sylhet',
      startAt: new Date(Date.now() + 345_600_000).toISOString(),
      capacity: 200,
      availableSeats: 65,
      price: 900,
    },
    {
      id: 'slot-6',
      category: 'Resort',
      providerName: "Sun Mariners Resort",
      location: "Cox's Bazar",
      startAt: new Date(Date.now() + 432_000_000).toISOString(),
      endAt: new Date(Date.now() + 518_400_000).toISOString(),
      capacity: 30,
      availableSeats: 9,
      price: 6200,
    },
    {
      id: 'slot-7',
      category: 'Micro-bus',
      providerName: 'Zahangir Travels',
      origin: 'Dhaka',
      destination: 'Chittagong',
      startAt: new Date(Date.now() + 100_800_000).toISOString(),
      capacity: 15,
      availableSeats: 4,
      price: 1200,
    },
    {
      id: 'slot-8',
      category: 'Launch',
      providerName: 'ML River Queen',
      origin: 'Dhaka',
      destination: 'Barisal',
      startAt: new Date(Date.now() + 187_200_000).toISOString(),
      capacity: 60,
      availableSeats: 25,
      price: 1500,
    },
    {
      id: 'slot-9',
      category: 'Airplane',
      providerName: 'Bengal Air',
      origin: 'Dhaka',
      destination: "Cox's Bazar",
      startAt: new Date(Date.now() + 518_400_000).toISOString(),
      capacity: 180,
      availableSeats: 40,
      price: 5800,
    },
    {
      id: 'slot-10',
      category: 'Convention Center',
      providerName: 'Dhaka Convention Hall',
      location: 'Dhaka',
      startAt: new Date(Date.now() + 604_800_000).toISOString(),
      capacity: 500,
      availableSeats: 210,
      price: 15000,
    },
    {
      id: 'slot-11',
      category: 'Buffet',
      providerName: "Cox's Bazar Beachside Buffet",
      location: "Cox's Bazar",
      startAt: new Date(Date.now() + 259_200_000).toISOString(),
      capacity: 100,
      availableSeats: 35,
      price: 850,
    },
  ];

  private readonly guides: GuideProfile[] = [
    {
      id: 'guide-1',
      name: 'Zamal Uddin',
      location: "Cox's Bazar",
      languages: ['Bangla', 'English'],
      rating: 4.8,
      priceLabel: '3500/day',
      negotiable: true,
    },
    {
      id: 'guide-2',
      name: 'Minhaj Karim',
      location: 'Sajek',
      languages: ['Bangla', 'English', 'Hindi'],
      rating: 4.6,
      priceLabel: '3000/day',
      negotiable: false,
    },
    {
      id: 'guide-3',
      name: 'Farhan Chowdhury',
      location: "Saint Martin's Island",
      languages: ['Bangla', 'English'],
      rating: 4.9,
      priceLabel: '3800/day',
      negotiable: true,
    },
    {
      id: 'guide-4',
      name: 'Mahbub Alam',
      location: 'Sylhet',
      languages: ['Bangla', 'English'],
      rating: 4.4,
      priceLabel: '3000/day',
      negotiable: true,
    },
    {
      id: 'guide-5',
      name: 'Kamrul Islam',
      location: 'Bandarban',
      languages: ['Bangla', 'English', 'Chakma'],
      rating: 4.7,
      priceLabel: '4000/day',
      negotiable: false,
    },
    {
      id: 'guide-6',
      name: 'Malik Rafi',
      location: "Cox's Bazar",
      languages: ['Bangla', 'English'],
      rating: 5.0,
      priceLabel: '3600/day',
      negotiable: true,
    },
    {
      id: 'guide-7',
      name: 'Tanvir Hasan',
      location: 'Rangamati',
      languages: ['Bangla', 'English', 'Hindi'],
      rating: 4.5,
      priceLabel: '3200/day',
      negotiable: false,
    },
  ];

  private readonly bookings: Booking[] = [
    {
      id: 'bk-100',
      slotId: 'slot-1',
      slotTitle: "Bus Dhaka -> Cox's Bazar",
      amount: 1800,
      status: 'Paid',
      bookedAt: new Date().toISOString(),
    },
    {
      id: 'bk-101',
      slotId: 'slot-2',
      slotTitle: "Ship Teknaf -> Saint Martin's Island",
      amount: 2500,
      status: 'Confirmed',
      bookedAt: new Date(Date.now() - 86_400_000).toISOString(),
    },
    {
      id: 'bk-102',
      slotId: 'slot-3',
      slotTitle: "Hotel Cox's Bazar",
      amount: 5500,
      status: 'Pending',
      bookedAt: new Date(Date.now() - 172_800_000).toISOString(),
    },
    {
      id: 'bk-103',
      slotId: 'slot-4',
      slotTitle: 'Amusement Park Sajek Valley',
      amount: 3000,
      status: 'Completed',
      bookedAt: new Date(Date.now() - 259_200_000).toISOString(),
    },
    {
      id: 'bk-104',
      slotId: 'slot-5',
      slotTitle: 'Train Dhaka -> Sylhet',
      amount: 900,
      status: 'Paid',
      bookedAt: new Date(Date.now() - 345_600_000).toISOString(),
    },
    {
      id: 'bk-105',
      slotId: 'slot-6',
      slotTitle: "Resort Cox's Bazar",
      amount: 6200,
      status: 'Confirmed',
      bookedAt: new Date(Date.now() - 432_000_000).toISOString(),
    },
    {
      id: 'bk-106',
      slotId: 'slot-10',
      slotTitle: 'Convention Center Dhaka',
      amount: 15000,
      status: 'Confirmed',
      bookedAt: new Date(Date.now() - 518_400_000).toISOString(),
    },
    {
      id: 'bk-107',
      slotId: 'slot-11',
      slotTitle: "Buffet Cox's Bazar",
      amount: 850,
      status: 'Paid',
      bookedAt: new Date(Date.now() - 604_800_000).toISOString(),
    },
  ];

  getSlots(): Observable<Slot[]> {
    return of(this.slots).pipe(delay(350));
  }

  getSlotById(slotId: string): Observable<Slot> {
    const slot = this.slots.find((entry) => entry.id === slotId);
    if (!slot) {
      return throwError(() => new Error('Slot not found'));
    }

    return of(slot).pipe(delay(250));
  }

  getGuides(): Observable<GuideProfile[]> {
    return of(this.guides).pipe(delay(300));
  }

  getGuideById(guideId: string): Observable<GuideProfile> {
    const guide = this.guides.find((entry) => entry.id === guideId);
    if (!guide) {
      return throwError(() => new Error('Guide not found'));
    }

    return of(guide).pipe(delay(250));
  }

  getBookings(): Observable<Booking[]> {
    return of(this.bookings).pipe(delay(300));
  }

  getTrackingPoints(): Observable<TrackingPoint[]> {
    const data: TrackingPoint[] = [
      {
        entity: 'Tourist',
        name: 'You',
        place: "Cox's Bazar",
        lat: 21.4272,
        lng: 92.0058,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Guide',
        name: 'Zamal Uddin',
        place: "Cox's Bazar",
        lat: 21.4272,
        lng: 92.0058,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Tour Mate',
        name: 'Rafi',
        place: "Cox's Bazar",
        lat: 21.4291,
        lng: 92.0061,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Tour Mate',
        name: 'Amin',
        place: "Cox's Bazar",
        lat: 21.4300,
        lng: 92.0070,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Guide',
        name: 'Minhaj Karim',
        place: 'Sajek Valley',
        lat: 22.4990,
        lng: 92.2932,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Tour Mate',
        name: 'Nusrat',
        place: 'Sajek Valley',
        lat: 22.4995,
        lng: 92.2940,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Guide',
        name: 'Farhan Chowdhury',
        place: "Saint Martin's Island",
        lat: 20.6270,
        lng: 92.3200,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Tour Mate',
        name: 'Sadia',
        place: "Saint Martin's Island",
        lat: 20.6275,
        lng: 92.3210,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Guide',
        name: 'Kamrul Islam',
        place: 'Bandarban',
        lat: 22.1953,
        lng: 92.2184,
        updatedAt: new Date().toISOString(),
      },
      {
        entity: 'Tour Mate',
        name: 'Tanvir',
        place: 'Rangamati',
        lat: 22.6533,
        lng: 92.1758,
        updatedAt: new Date().toISOString(),
      },
    ];

    return of(data).pipe(delay(450));
  }
}
