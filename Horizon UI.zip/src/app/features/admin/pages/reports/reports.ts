import { Component, inject, signal } from '@angular/core';
import { AdminDataService } from '../../../../mock-data/admin-data';
import { ReportSummary } from '../../../../models/admin.model';

@Component({
  selector: 'app-admin-reports',
  imports: [],
  templateUrl: './reports.html',
  styleUrl: './reports.scss',
})
export class Reports {
  private readonly adminData = inject(AdminDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly summary = signal<ReportSummary[]>([]);

  constructor() {
    this.loadSummary();
  }

  private loadSummary(): void {
    this.loading.set(true);
    this.error.set('');
    this.adminData.getReportSummary().subscribe({
      next: (data) => {
        this.summary.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load reports.');
        this.loading.set(false);
      },
    });
  }
}
