import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminDataService } from '../../../../mock-data/admin-data';
import { PendingRegistration } from '../../../../models/admin.model';

@Component({
  selector: 'app-pending-registrations',
  imports: [DatePipe],
  templateUrl: './pending-registrations.html',
  styleUrl: './pending-registrations.scss',
})
export class PendingRegistrations {
  private readonly adminData = inject(AdminDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly registrations = signal<PendingRegistration[]>([]);

  constructor() {
    this.loadRegistrations();
  }

  private loadRegistrations(): void {
    this.loading.set(true);
    this.error.set('');
    this.adminData.getPendingRegistrations().subscribe({
      next: (items) => {
        this.registrations.set(items);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load pending registrations.');
        this.loading.set(false);
      },
    });
  }

  approve(id: string): void {
    this.adminData.approveRegistration(id).subscribe(() => this.loadRegistrations());
  }

  reject(id: string): void {
    this.adminData.rejectRegistration(id).subscribe(() => this.loadRegistrations());
  }
}
