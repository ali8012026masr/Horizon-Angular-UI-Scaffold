import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminDataService } from '../../../../mock-data/admin-data';
import { ProviderLedgerRow } from '../../../../models/admin.model';

@Component({
  selector: 'app-admin-ledger',
  imports: [DatePipe],
  templateUrl: './ledger.html',
  styleUrl: './ledger.scss',
})
export class Ledger {
  private readonly adminData = inject(AdminDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly rows = signal<ProviderLedgerRow[]>([]);

  constructor() {
    this.loadRows();
  }

  private loadRows(): void {
    this.loading.set(true);
    this.error.set('');
    this.adminData.getLedgerRows().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load ledger rows.');
        this.loading.set(false);
      },
    });
  }
}
