import { Component, inject, signal } from '@angular/core';
import { AdminDataService } from '../../../../mock-data/admin-data';
import { RoleUser } from '../../../../models/admin.model';

@Component({
  selector: 'app-role-management',
  imports: [],
  templateUrl: './role-management.html',
  styleUrl: './role-management.scss',
})
export class RoleManagement {
  private readonly adminData = inject(AdminDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly users = signal<RoleUser[]>([]);

  constructor() {
    this.loadUsers();
  }

  private loadUsers(): void {
    this.loading.set(true);
    this.error.set('');
    this.adminData.getUsers().subscribe({
      next: (users) => {
        this.users.set(users);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Failed to load users.');
        this.loading.set(false);
      },
    });
  }

  updateStatus(id: string, status: 'Active' | 'Suspended' | 'Revoked'): void {
    this.adminData.updateUserStatus(id, status).subscribe(() => this.loadUsers());
  }
}
