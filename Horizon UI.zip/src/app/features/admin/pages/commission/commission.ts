import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminDataService } from '../../../../mock-data/admin-data';
import { CommissionRow } from '../../../../models/admin.model';

@Component({
  selector: 'app-admin-commission',
  imports: [DatePipe],
  templateUrl: './commission.html',
  styleUrl: './commission.scss',
})
export class Commission {
  private readonly adminData = inject(AdminDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly rows = signal<CommissionRow[]>([]);

  constructor() {
    this.loadRows();
  }

  private loadRows(): void {
    this.loading.set(true);
    this.error.set('');
    this.adminData.getCommissionRows().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load commission data.');
        this.loading.set(false);
      },
    });
  }
}
