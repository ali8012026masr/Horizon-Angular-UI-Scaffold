import { Component, inject } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { GuideProfile } from '../../../../models/guide.model';

@Component({
  selector: 'app-browse-guides',
  imports: [RouterLink, DecimalPipe, ReactiveFormsModule],
  templateUrl: './browse-guides.html',
  styleUrl: './browse-guides.scss',
})
export class BrowseGuides {
  private readonly fb = inject(FormBuilder);
  private readonly touristDataService = inject(TouristDataService);
  loading = true;
  error = '';
  guides: GuideProfile[] = [];
  readonly filterForm = this.fb.nonNullable.group({
    location: [''],
  });

  constructor() {
    this.touristDataService
      .getGuides()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((guides) => {
        this.guides = guides;
        this.loading = false;
      });
  }

  get filteredGuides(): GuideProfile[] {
    const location = this.filterForm.controls.location.value.trim().toLowerCase();
    if (!location) {
      return this.guides;
    }

    return this.guides.filter((guide) => guide.location.toLowerCase().includes(location));
  }
}
