import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { GuideProfile } from '../../../../models/guide.model';

@Component({
  selector: 'app-select-guide',
  imports: [RouterLink],
  templateUrl: './select-guide.html',
  styleUrl: './select-guide.scss',
})
export class SelectGuide {
  private readonly route = inject(ActivatedRoute);
  private readonly touristDataService = inject(TouristDataService);

  loading = true;
  error = '';
  guide: GuideProfile | null = null;

  constructor() {
    const guideId = this.route.snapshot.paramMap.get('id');
    if (!guideId) {
      this.error = 'Guide ID is missing.';
      this.loading = false;
      return;
    }

    this.touristDataService
      .getGuideById(guideId)
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of(null);
        })
      )
      .subscribe((guide) => {
        this.guide = guide;
        this.loading = false;
      });
  }
}
