import { Component, inject } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { Booking } from '../../../../models/booking.model';
import { SlotCategory } from '../../../../models/slot.model';

interface BookedServiceRow extends Booking {
  category: SlotCategory | 'Guide';
}

@Component({
  selector: 'app-my-bookings',
  imports: [DatePipe, DecimalPipe, RouterLink],
  templateUrl: './my-bookings.html',
  styleUrl: './my-bookings.scss',
})
export class MyBookings {
  private readonly touristDataService = inject(TouristDataService);
  loading = true;
  error = '';
  rows: BookedServiceRow[] = [];

  constructor() {
    forkJoin({
      bookings: this.touristDataService.getBookings(),
      slots: this.touristDataService.getSlots(),
    })
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of({ bookings: [], slots: [] });
        })
      )
      .subscribe(({ bookings, slots }) => {
        this.rows = bookings.map((booking) => ({
          ...booking,
          category: slots.find((slot) => slot.id === booking.slotId)?.category ?? 'Guide',
        }));
        this.loading = false;
      });
  }
}
