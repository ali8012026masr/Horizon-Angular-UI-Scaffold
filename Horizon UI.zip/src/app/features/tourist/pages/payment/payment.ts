import { Component, inject, signal } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { Slot } from '../../../../models/slot.model';

@Component({
  selector: 'app-payment',
  imports: [ReactiveFormsModule, DatePipe, DecimalPipe],
  templateUrl: './payment.html',
  styleUrl: './payment.scss',
})
export class Payment {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);
  private readonly touristDataService = inject(TouristDataService);
  readonly paymentState = signal<'idle' | 'success' | 'failed'>('idle');

  loading = true;
  error = '';
  slot: Slot | null = null;

  readonly paymentForm = this.fb.nonNullable.group({
    method: ['Card', Validators.required],
    cardNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{16}$/)]],
    cvv: ['', [Validators.required, Validators.pattern(/^[0-9]{3}$/)]],
  });

  constructor() {
    const slotId = this.route.snapshot.paramMap.get('id');
    if (!slotId) {
      this.error = 'Invalid slot selection for payment.';
      this.loading = false;
      return;
    }

    this.touristDataService
      .getSlotById(slotId)
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of(null);
        })
      )
      .subscribe((slot) => {
        this.slot = slot;
        this.loading = false;
      });
  }

  pay(): void {
    if (this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      return;
    }

    const cardNumber = this.paymentForm.controls.cardNumber.value;
    if (cardNumber.endsWith('0')) {
      this.paymentState.set('failed');
      return;
    }

    this.paymentState.set('success');
    setTimeout(() => {
      void this.router.navigate(['/tourist/booking-confirmation']);
    }, 800);
  }
}
