import { Component, signal, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-request-guide',
  imports: [ReactiveFormsModule],
  templateUrl: './request-guide.html',
  styleUrl: './request-guide.scss',
})
export class RequestGuide {
  private readonly fb = inject(FormBuilder);
  readonly submitted = signal(false);
  readonly form = this.fb.nonNullable.group({
    date: ['', Validators.required],
    note: ['', [Validators.required, Validators.minLength(10)]],
    proposedPrice: [3000, [Validators.required, Validators.min(500)]],
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.submitted.set(true);
  }
}
