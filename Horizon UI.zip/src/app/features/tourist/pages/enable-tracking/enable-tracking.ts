import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-enable-tracking',
  imports: [RouterLink],
  templateUrl: './enable-tracking.html',
  styleUrl: './enable-tracking.scss',
})
export class EnableTracking {
  readonly gpsEnabled = signal(false);
}
