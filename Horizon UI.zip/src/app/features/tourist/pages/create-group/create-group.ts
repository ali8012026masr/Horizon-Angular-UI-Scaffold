import { Component, inject, signal } from '@angular/core';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-create-group',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './create-group.html',
  styleUrl: './create-group.scss',
})
export class CreateGroup {
  private readonly fb = inject(FormBuilder);
  readonly created = signal(false);
  readonly form = this.fb.nonNullable.group({
    groupName: ['', [Validators.required, Validators.minLength(3)]],
    mates: this.fb.array([this.fb.nonNullable.control('', [Validators.required, Validators.email])]),
  });

  get mates(): FormArray {
    return this.form.controls.mates;
  }

  addMate(): void {
    this.mates.push(this.fb.nonNullable.control('', [Validators.required, Validators.email]));
  }

  create(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.created.set(true);
  }
}
