import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-rate-services',
  imports: [ReactiveFormsModule],
  templateUrl: './rate-services.html',
  styleUrl: './rate-services.scss',
})
export class RateServices {
  private readonly fb = inject(FormBuilder);
  readonly submitted = signal(false);
  readonly form = this.fb.nonNullable.group({
    serviceType: ['', Validators.required],
    rating: [5, [Validators.required, Validators.min(1), Validators.max(5)]],
    comment: ['', [Validators.required, Validators.minLength(8)]],
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.submitted.set(true);
  }
}
