import { Component, inject } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { Booking } from '../../../../models/booking.model';

@Component({
  selector: 'app-booking-confirmation',
  imports: [DatePipe, CurrencyPipe, RouterLink],
  templateUrl: './booking-confirmation.html',
  styleUrl: './booking-confirmation.scss',
})
export class BookingConfirmation {
  private readonly touristDataService = inject(TouristDataService);
  loading = true;
  error = '';
  bookings: Booking[] = [];

  constructor() {
    this.touristDataService
      .getBookings()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((bookings) => {
        this.bookings = bookings;
        this.loading = false;
      });
  }
}
