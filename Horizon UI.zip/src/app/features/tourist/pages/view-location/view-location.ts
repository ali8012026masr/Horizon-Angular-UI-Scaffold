import { Component, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { TrackingPoint } from '../../../../models/tracking.model';

@Component({
  selector: 'app-view-location',
  imports: [DatePipe],
  templateUrl: './view-location.html',
  styleUrl: './view-location.scss',
})
export class ViewLocation {
  private readonly touristDataService = inject(TouristDataService);
  loading = true;
  error = '';
  points: TrackingPoint[] = [];

  constructor() {
    this.touristDataService
      .getTrackingPoints()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((points) => {
        this.points = points;
        this.loading = false;
      });
  }
}
