import { Component, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { Slot } from '../../../../models/slot.model';

@Component({
  selector: 'app-group-booking',
  imports: [RouterLink, DatePipe],
  templateUrl: './group-booking.html',
  styleUrl: './group-booking.scss',
})
export class GroupBooking {
  private readonly touristDataService = inject(TouristDataService);
  loading = true;
  error = '';
  slots: Slot[] = [];

  constructor() {
    this.touristDataService
      .getSlots()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((slots) => {
        this.slots = slots.filter((slot) => !!slot.origin);
        this.loading = false;
      });
  }
}
