import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-group-join',
  imports: [RouterLink],
  templateUrl: './group-join.html',
  styleUrl: './group-join.scss',
})
export class GroupJoin {}
