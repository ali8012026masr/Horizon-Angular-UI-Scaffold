import { Component, inject } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { LookupDataService } from '../../../../mock-data/lookup-data';
import { Slot } from '../../../../models/slot.model';

@Component({
  selector: 'app-browse-slots',
  imports: [ReactiveFormsModule, RouterLink, DatePipe, DecimalPipe],
  templateUrl: './browse-slots.html',
  styleUrl: './browse-slots.scss',
})
export class BrowseSlots {
  private readonly fb = inject(FormBuilder);
  private readonly touristDataService = inject(TouristDataService);
  readonly categories = inject(LookupDataService).slotCategories;
  loading = true;
  error = '';
  slots: Slot[] = [];

  readonly filterForm = this.fb.nonNullable.group({
    category: [''],
    origin: [''],
    destination: [''],
    date: [''],
  });

  constructor() {
    this.fetchSlots();
  }

  get filteredSlots(): Slot[] {
    const { category, origin, destination, date } = this.filterForm.getRawValue();

    return this.slots.filter((slot) => {
      const place = `${slot.origin ?? ''} ${slot.location ?? ''}`.toLowerCase();
      const byCategory = !category || slot.category === category;
      const byOrigin = !origin || place.includes(origin.toLowerCase());
      const byDestination =
        !destination || (slot.destination ?? '').toLowerCase().includes(destination.toLowerCase());
      const byDate = !date || slot.startAt.startsWith(date);
      return byCategory && byOrigin && byDestination && byDate;
    });
  }

  private fetchSlots(): void {
    this.loading = true;
    this.error = '';
    this.touristDataService
      .getSlots()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((slots) => {
        this.slots = slots;
        this.loading = false;
      });
  }
}
