import { Component, inject } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { TouristDataService } from '../../../../mock-data/tourist-data';
import { Slot } from '../../../../models/slot.model';

@Component({
  selector: 'app-select-slot',
  imports: [DatePipe, DecimalPipe, RouterLink],
  templateUrl: './select-slot.html',
  styleUrl: './select-slot.scss',
})
export class SelectSlot {
  private readonly route = inject(ActivatedRoute);
  private readonly touristDataService = inject(TouristDataService);

  loading = true;
  error = '';
  slot: Slot | null = null;

  constructor() {
    const slotId = this.route.snapshot.paramMap.get('id');
    if (!slotId) {
      this.error = 'Invalid slot selection.';
      this.loading = false;
      return;
    }

    this.touristDataService
      .getSlotById(slotId)
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of(null);
        })
      )
      .subscribe((slot) => {
        this.slot = slot;
        this.loading = false;
      });
  }
}
