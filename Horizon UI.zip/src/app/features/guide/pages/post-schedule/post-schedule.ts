import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-schedule',
  imports: [ReactiveFormsModule],
  templateUrl: './post-schedule.html',
  styleUrl: './post-schedule.scss',
})
export class PostSchedule {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  readonly posted = signal(false);
  readonly form = this.fb.nonNullable.group({
    location: ['', [Validators.required, Validators.minLength(2)]],
    spot: ['', [Validators.required, Validators.minLength(3)]],
    date: ['', Validators.required],
    time: ['', Validators.required],
    price: [null, [Validators.required, Validators.min(100)]],
    negotiable: [false],
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.posted.set(true);
    setTimeout(() => void this.router.navigate(['/guide/dashboard']), 800);
  }
}
