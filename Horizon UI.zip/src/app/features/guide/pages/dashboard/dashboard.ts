import { Component } from '@angular/core';

@Component({
  selector: 'app-guide-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss',
})
export class Dashboard {}
