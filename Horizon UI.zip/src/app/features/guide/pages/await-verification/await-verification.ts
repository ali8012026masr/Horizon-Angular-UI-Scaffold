import { Component } from '@angular/core';

@Component({
  selector: 'app-await-verification',
  imports: [],
  templateUrl: './await-verification.html',
  styleUrl: './await-verification.scss',
})
export class AwaitVerification {}
