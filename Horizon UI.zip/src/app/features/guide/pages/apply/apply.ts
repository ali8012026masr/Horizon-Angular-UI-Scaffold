import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-apply-guide',
  imports: [ReactiveFormsModule],
  templateUrl: './apply.html',
  styleUrl: './apply.scss',
})
export class ApplyGuide {
  private readonly fb = inject(FormBuilder);
  readonly submitted = signal(false);
  readonly form = this.fb.nonNullable.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
    nationalId: ['', [Validators.required, Validators.pattern(/^[0-9]{10,17}$/)]],
    location: ['', [Validators.required, Validators.minLength(2)]],
    experience: ['', [Validators.required, Validators.minLength(10)]],
    price: [null, [Validators.required, Validators.min(100)]],
    negotiable: [false],
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitted.set(true);
  }
}
