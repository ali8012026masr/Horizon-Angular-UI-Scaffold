import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { GuideBookingRequest } from '../../../../models/guide.model';
import { GuideDataService } from '../../../../mock-data/guide-data';

@Component({
  selector: 'app-guide-bookings',
  imports: [DatePipe],
  templateUrl: './bookings.html',
  styleUrl: './bookings.scss',
})
export class Bookings {
  private readonly guideData = inject(GuideDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly requests = signal<GuideBookingRequest[]>([]);

  constructor() {
    this.loadRequests();
  }

  private loadRequests(): void {
    this.loading.set(true);
    this.error.set('');
    this.guideData.getBookingRequests().subscribe({
      next: (data) => {
        this.requests.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Failed to load booking requests.');
        this.loading.set(false);
      },
    });
  }

  accept(requestId: string): void {
    this.guideData.acceptRequest(requestId).subscribe(() => this.loadRequests());
  }

  decline(requestId: string): void {
    this.guideData.declineRequest(requestId).subscribe(() => this.loadRequests());
  }
}
