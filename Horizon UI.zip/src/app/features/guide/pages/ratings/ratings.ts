import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { GuideDataService } from '../../../../mock-data/guide-data';
import { GuideRating } from '../../../../models/guide.model';

@Component({
  selector: 'app-guide-ratings',
  imports: [DatePipe],
  templateUrl: './ratings.html',
  styleUrl: './ratings.scss',
})
export class Ratings {
  private readonly guideData = inject(GuideDataService);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly ratings = signal<GuideRating[]>([]);

  constructor() {
    this.loadRatings();
  }

  private loadRatings(): void {
    this.loading.set(true);
    this.error.set('');
    this.guideData.getRatings().subscribe({
      next: (ratings) => {
        this.ratings.set(ratings);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load ratings.');
        this.loading.set(false);
      },
    });
  }
}
