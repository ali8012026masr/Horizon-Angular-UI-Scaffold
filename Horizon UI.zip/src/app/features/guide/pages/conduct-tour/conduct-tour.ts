import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-conduct-tour',
  imports: [],
  templateUrl: './conduct-tour.html',
  styleUrl: './conduct-tour.scss',
})
export class ConductTour {
  readonly sharingEnabled = signal(false);
  readonly paymentRequested = signal(false);
  readonly paymentReceived = signal(false);

  toggleSharing(): void {
    this.sharingEnabled.update((value) => !value);
  }

  requestPayment(): void {
    this.paymentRequested.set(true);
  }

  receivePayment(): void {
    this.paymentReceived.set(true);
  }
}
