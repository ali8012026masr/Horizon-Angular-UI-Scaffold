import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { LookupDataService } from '../../../../mock-data/lookup-data';

@Component({
  selector: 'app-register-business',
  imports: [ReactiveFormsModule],
  templateUrl: './register-business.html',
  styleUrl: './register-business.scss',
})
export class RegisterBusiness {
  private readonly fb = inject(FormBuilder);
  readonly categories = inject(LookupDataService).slotCategories;
  readonly submitted = signal(false);
  readonly form = this.fb.nonNullable.group({
    businessName: ['', [Validators.required, Validators.minLength(3)]],
    ownerEmail: ['', [Validators.required, Validators.email]],
    category: ['', Validators.required],
    tradeLicense: ['', Validators.required],
    nationalId: ['', [Validators.required, Validators.pattern(/^[0-9]{10,17}$/)]],
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitted.set(true);
  }
}
