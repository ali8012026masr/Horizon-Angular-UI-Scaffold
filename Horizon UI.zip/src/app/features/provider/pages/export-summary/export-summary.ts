import { Component } from '@angular/core';

@Component({
  selector: 'app-export-summary',
  imports: [],
  templateUrl: './export-summary.html',
  styleUrl: './export-summary.scss',
})
export class ExportSummary {}
