import { Component, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LookupDataService } from '../../../../mock-data/lookup-data';
import { SlotCategory } from '../../../../models/slot.model';

type SlotFormType = 'transport' | 'stay' | 'venue' | 'dining' | 'amusement';

const FORM_TYPE_BY_CATEGORY: Record<SlotCategory, SlotFormType> = {
  Bus: 'transport',
  'Micro-bus': 'transport',
  Launch: 'transport',
  Train: 'transport',
  Airplane: 'transport',
  Ship: 'transport',
  Hotel: 'stay',
  Resort: 'stay',
  'Convention Center': 'venue',
  Buffet: 'dining',
  'Amusement Park': 'amusement',
};

@Component({
  selector: 'app-enter-slot-details',
  imports: [ReactiveFormsModule],
  templateUrl: './enter-slot-details.html',
  styleUrl: './enter-slot-details.scss',
})
export class EnterSlotDetails {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  readonly categories = inject(LookupDataService).slotCategories;

  readonly category = signal<SlotCategory>('Bus');
  readonly formType = computed<SlotFormType>(() => FORM_TYPE_BY_CATEGORY[this.category()]);

  readonly form = this.fb.nonNullable.group({
    category: ['Bus' as SlotCategory, Validators.required],
    origin: ['', Validators.required],
    destination: ['', Validators.required],
    startDate: ['', Validators.required],
    startTime: ['', Validators.required],
    capacity: [1, [Validators.required, Validators.min(1), Validators.max(500)]],
    price: [100, [Validators.required, Validators.min(1)]],
    endDate: ['', Validators.required],
    venueName: ['', Validators.required],
  });

  onCategoryChange(): void {
    this.category.set(this.form.controls.category.value);
  }

  publish(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    void this.router.navigate(['/provider/slots/publish']);
  }
}
