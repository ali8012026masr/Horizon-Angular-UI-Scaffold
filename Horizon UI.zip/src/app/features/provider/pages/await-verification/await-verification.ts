import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-await-verification',
  imports: [RouterLink],
  templateUrl: './await-verification.html',
  styleUrl: './await-verification.scss',
})
export class AwaitVerification {}
