import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-table',
  imports: [],
  templateUrl: './payment-table.html',
  styleUrl: './payment-table.scss',
})
export class PaymentTable {}
