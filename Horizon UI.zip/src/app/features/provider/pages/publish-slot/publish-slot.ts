import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-publish-slot',
  imports: [RouterLink],
  templateUrl: './publish-slot.html',
  styleUrl: './publish-slot.scss',
})
export class PublishSlot {}
