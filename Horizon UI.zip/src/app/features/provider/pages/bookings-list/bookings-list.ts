import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { catchError, of } from 'rxjs';
import { ProviderDataService, ProviderBookingRow } from '../../../../mock-data/provider-data';

@Component({
  selector: 'app-bookings-list',
  imports: [RouterLink],
  templateUrl: './bookings-list.html',
  styleUrl: './bookings-list.scss',
})
export class BookingsList {
  private readonly providerDataService = inject(ProviderDataService);
  loading = true;
  error = '';
  rows: ProviderBookingRow[] = [];

  constructor() {
    this.providerDataService
      .getBookings()
      .pipe(
        catchError((error: Error) => {
          this.error = error.message;
          return of([]);
        })
      )
      .subscribe((rows) => {
        this.rows = rows;
        this.loading = false;
      });
  }
}
