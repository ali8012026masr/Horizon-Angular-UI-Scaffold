import { Component } from '@angular/core';

@Component({
  selector: 'app-update-booking-status',
  imports: [],
  templateUrl: './update-booking-status.html',
  styleUrl: './update-booking-status.scss',
})
export class UpdateBookingStatus {}
