import { Component, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { LookupDataService } from '../../mock-data/lookup-data';
import { TouristDataService } from '../../mock-data/tourist-data';
import { Slot } from '../../models/slot.model';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, DatePipe],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.scss',
})
export class LandingComponent {
  private readonly fb = inject(FormBuilder);
  private readonly lookup = inject(LookupDataService);
  private readonly touristData = inject(TouristDataService);

  readonly categories = this.lookup.slotCategories;
  readonly loading = signal(true);
  readonly error = signal('');
  readonly slots = signal<Slot[]>([]);
  readonly filteredSlots = signal<Slot[]>([]);

  readonly searchForm = this.fb.nonNullable.group({
    category: ['', Validators.required],
    origin: [''],
    destination: [''],
  });

  constructor() {
    this.loadSlots();
  }

  private loadSlots(): void {
    this.loading.set(true);
    this.error.set('');
    this.touristData.getSlots().subscribe({
      next: (slots) => {
        this.slots.set(slots);
        this.filteredSlots.set(slots);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load available slots at this time.');
        this.loading.set(false);
      },
    });
  }

  search(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    const { category, origin, destination } = this.searchForm.getRawValue();
    const queryOrigin = origin.trim().toLowerCase();
    const queryDestination = destination.trim().toLowerCase();

    this.filteredSlots.set(
      this.slots()
        .filter((slot) => slot.category === category)
        .filter((slot) => {
          const place = `${slot.origin ?? ''} ${slot.location ?? ''}`.toLowerCase();
          return (
            (!queryOrigin || place.includes(queryOrigin)) &&
            (!queryDestination || (slot.destination ?? '').toLowerCase().includes(queryDestination))
          );
        })
    );
  }

  resetSearch(): void {
    this.searchForm.reset({ category: '', origin: '', destination: '' });
    this.filteredSlots.set(this.slots());
  }
}
