export type BookingStatus = 'Pending' | 'Paid' | 'Confirmed' | 'Completed';

export interface Booking {
  id: string;
  slotId: string;
  slotTitle: string;
  amount: number;
  status: BookingStatus;
  bookedAt: string;
}
