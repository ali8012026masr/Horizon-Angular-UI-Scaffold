export interface GuideProfile {
  id: string;
  name: string;
  location: string;
  languages: string[];
  rating: number;
  priceLabel: string;
  negotiable: boolean;
}

export interface GuideBookingRequest {
  id: string;
  tourist: string;
  tourLocation: string;
  scheduledDate: string;
  status: 'Pending' | 'Accepted' | 'Declined';
  amount: number;
}

export interface GuideRating {
  id: string;
  tourist: string;
  score: number;
  comment: string;
  receivedAt: string;
}
