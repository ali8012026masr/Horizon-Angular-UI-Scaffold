import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./features/landing/landing.component').then((m) => m.LandingComponent),
  },
  {
    path: 'auth',
    loadComponent: () => import('./core/layouts/auth-shell/auth-shell').then((m) => m.AuthShell),
  },
  {
    path: 'tourist',
    loadChildren: () =>
      import('./features/tourist/tourist.routes').then((m) => m.TOURIST_ROUTES),
  },
  {
    path: 'provider',
    loadChildren: () =>
      import('./features/provider/provider.routes').then((m) => m.PROVIDER_ROUTES),
  },
  {
    path: 'guide',
    loadChildren: () => import('./features/guide/guide.routes').then((m) => m.GUIDE_ROUTES),
  },
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then((m) => m.ADMIN_ROUTES),
  },
  {
    path: '**',
    redirectTo: '',
  },
];
